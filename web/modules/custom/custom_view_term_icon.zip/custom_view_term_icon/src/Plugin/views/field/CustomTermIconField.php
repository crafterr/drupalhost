<?php

declare(strict_types=1);

namespace Drupal\custom_view_term_icon\Plugin\views\field;

use Drupal\Component\Render\MarkupInterface;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Render\Markup;
use Drupal\taxonomy\Entity\Term;
use Drupal\views\Plugin\views\field\FieldPluginBase;
use Drupal\views\ResultRow;

/**
 * Provides a custom Views field for displaying taxonomy term icons.
 *
 * @ViewsField("term_icon")
 */
class CustomTermIconField extends FieldPluginBase {

  /**
   * {@inheritdoc}
   */
  public function defineOptions(): array {
    $options = parent::defineOptions();
    $options['template_type'] = ['default' => 'template1'];
    $options['term_source'] = ['default' => ''];
    return $options;
  }

  /**
   * {@inheritdoc}
   */
  public function buildOptionsForm(&$form, FormStateInterface $form_state) {
    parent::buildOptionsForm($form, $form_state);

    // Template selection.
    $form['template_type'] = [
      '#type' => 'select',
      '#title' => $this->t('Select template'),
      '#options' => [
        'template1' => $this->t('Template 1'),
        'template2' => $this->t('Template 2'),
        'template3' => $this->t('Template 3'),
      ],
      '#default_value' => $this->options['template_type'],
    ];

    // Dynamic select for term source (available relationships).
    $relationship_options = [];

    if (!empty($this->view) && $this->view->display_handler) {
      $relationships = $this->view->display_handler->getOption('relationships');
      if (is_array($relationships)) {
        foreach ($relationships as $machine_name => $definition) {
          $label = $machine_name;
          if (!empty($definition['label'])) {
            $label .= ' (' . $definition['label'] . ')';
          }
          $relationship_options[$machine_name] = $label;
        }
      }
    }

    $form['term_source'] = [
      '#type' => 'select',
      '#title' => $this->t('Select taxonomy term source'),
      '#options' => $relationship_options ?: ['' => $this->t('- No relationships available -')],
      '#default_value' => $this->options['term_source'] ?? '',
      '#description' => $this->t('Choose the relationship key used to get taxonomy terms.'),
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function query(): void {
    // No database query needed as this is a computed field.
  }

  /**
   * {@inheritdoc}
   */
  public function render(ResultRow $values): string|MarkupInterface {
    $output = '';
    $template = $this->options['template_type'];
    $term_key = $this->options['term_source'] ?? '';

    $terms = [];

    if (!empty($term_key) && isset($values->_relationship_entities[$term_key])) {
      $entity = $values->_relationship_entities[$term_key];

      if ($entity instanceof Term) {
        $terms[] = $entity;
      }
      elseif (is_array($entity)) {
        foreach ($entity as $item) {
          if ($item instanceof Term) {
            $terms[] = $item;
          }
        }
      }
    }

    if (empty($terms)) {
      return '';
    }

    foreach ($terms as $term) {
      $label = $term->label();
      $code = $term->get('field_sport_code')->value ?? '';
      if (empty($code)) {
        continue;
      }

      $codename = strtolower(str_replace(' ', '_', $code));

      switch ($template) {
        case 'template1':
          $output .= '<div class="sport-icon ' . $codename . '" title="' . $label . '">- render temp1: '.$codename.'</div>';
          break;

        case 'template2':
          $output .= '<span class="sport-badge badge-' . $codename . '">' . $label . '</span>';
          break;

        case 'template3':
          $output .= '<img class="sport-img" src="/icons/' . $codename . '.svg" alt="' . $label . '" />';
          break;
      }
    }

    return Markup::create($output);
  }

}
